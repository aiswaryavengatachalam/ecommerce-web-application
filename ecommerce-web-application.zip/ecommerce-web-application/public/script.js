const products=[
{id:1,name:"Laptop",price:55000,icon:"💻"},
{id:2,name:"Smartphone",price:25000,icon:"📱"},
{id:3,name:"Headphones",price:2500,icon:"🎧"},
{id:4,name:"Smart Watch",price:4500,icon:"⌚"},
{id:5,name:"Keyboard",price:1800,icon:"⌨️"},
{id:6,name:"Camera",price:32000,icon:"📷"}
];
let cart=JSON.parse(localStorage.getItem("cart")||"[]");

function renderProducts(){
 document.getElementById("productList").innerHTML=products.map(p=>`
 <div class="product"><div class="image">${p.icon}</div><h3>${p.name}</h3>
 <div class="price">₹${p.price.toLocaleString()}</div>
 <button onclick="addToCart(${p.id})">Add to Cart</button></div>`).join("");
}
function addToCart(id){const p=products.find(x=>x.id===id);cart.push(p);save();renderCart()}
function removeItem(i){cart.splice(i,1);save();renderCart()}
function save(){localStorage.setItem("cart",JSON.stringify(cart))}
function renderCart(){
 const box=document.getElementById("cartItems");
 box.innerHTML=cart.length?cart.map((p,i)=>`<div class="cart-row"><span>${p.icon} ${p.name} - ₹${p.price.toLocaleString()}</span><button onclick="removeItem(${i})">Remove</button></div>`).join(""):"<p>Your cart is empty.</p>";
 document.getElementById("total").textContent=cart.reduce((s,p)=>s+p.price,0).toLocaleString();
 document.getElementById("count").textContent=cart.length;
}
async function login(){
 const email=document.getElementById("email").value,password=document.getElementById("password").value;
 const res=await fetch("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email,password})});
 const data=await res.json();document.getElementById("message").textContent=data.message;
}
async function checkout(){
 if(!cart.length)return alert("Add a product to cart first.");
 const res=await fetch("/api/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({items:cart,total:cart.reduce((s,p)=>s+p.price,0)})});
 const data=await res.json();alert(data.message);cart=[];save();renderCart();
}
renderProducts();renderCart();