# E-Commerce Web Application

ShopEasy is a responsive full-stack e-commerce web application.

## Features
- Product catalog
- Add to cart
- Checkout and order creation
- User/Admin login roles
- Product API
- Order management API
- Responsive design
- Local cart storage

## Technologies
HTML, CSS, JavaScript, Node.js and Express.js.

## Demo Login
Admin: admin@shop.com / admin123
User: user@shop.com / user123

## Run
npm install
npm start
Open http://localhost:3000
