const express=require("express");
const crypto=require("crypto");
const path=require("path");
const app=express();
const PORT=process.env.PORT||3000;
app.use(express.json());
app.use(express.static(path.join(__dirname,"public")));

const users=[
 {id:"1",name:"Admin",email:"admin@shop.com",password:"admin123",role:"Admin"},
 {id:"2",name:"User",email:"user@shop.com",password:"user123",role:"User"}
];
const orders=[];

app.post("/api/login",(req,res)=>{
 const {email,password}=req.body;
 const user=users.find(u=>u.email===email&&u.password===password);
 if(!user)return res.status(401).json({message:"Invalid login details"});
 res.json({message:`Login successful - ${user.role}`,user:{id:user.id,name:user.name,role:user.role}});
});

app.get("/api/products",(req,res)=>res.json([
 {id:1,name:"Laptop",price:55000},
 {id:2,name:"Smartphone",price:25000},
 {id:3,name:"Headphones",price:2500}
]));

app.post("/api/products",(req,res)=>{
 const {name,price}=req.body;
 res.status(201).json({message:"Product API ready",product:{id:crypto.randomUUID(),name,price}});
});

app.post("/api/orders",(req,res)=>{
 const order={id:crypto.randomUUID(),items:req.body.items,total:req.body.total,status:"Placed",createdAt:new Date().toISOString()};
 orders.push(order);
 res.status(201).json({message:"Order placed successfully",order});
});

app.get("/api/orders",(req,res)=>res.json(orders));

app.listen(PORT,()=>console.log(`ShopEasy running at http://localhost:${PORT}`));